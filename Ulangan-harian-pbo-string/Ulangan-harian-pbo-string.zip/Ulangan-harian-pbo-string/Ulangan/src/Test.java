public class Test {
    public static void main(String[] args) {
        int nilai = 2; 
        int pangkat = 2; 
        Double hasil;
        hasil = Math.pow(nilai, pangkat);
        System.out.println("Variable nilai : " + nilai);
        System.out.println("Variable pangkat : " + pangkat);
        System.out.println("hasil " + hasil);
    }
}
