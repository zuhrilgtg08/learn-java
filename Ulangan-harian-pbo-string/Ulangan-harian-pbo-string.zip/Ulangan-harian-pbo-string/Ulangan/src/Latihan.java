public class Latihan {
    public static void main(String[] args) {
        String nama = "Ahmad Zuhril Fahrizal";
        String alamat = "JL Margodadi 1 No 24";
        String tempat_tgl_lahir = "Surabaya, 06 Agustus 2004";
        String agama = "Islam";
        String status = "Pelajar";
        String pengalaman = "Saya mulai tertarik dengan programming sejak kelas 10 awal awal masuk sekolah dan itu saya \n tertarik dengan web programming";
        int umur = 18;

        System.out.println();
        System.out.println("\t========================================================================");
        System.out.println("\t\t\t\tBiodataku");
        System.out.println("\t========================================================================");
        System.out.println("\tNama\t\t\t: " + nama);
        System.out.println("\tAlamat\t\t\t: " + alamat);
        System.out.println("\tTempat/Tanggal Lahir\t: " + tempat_tgl_lahir);
        System.out.println("\tAgama\t\t\t: " + agama);
        System.out.println("\tStatus\t\t\t: " + status);
        System.out.println("\tUmur\t\t\t: " + umur);
        System.out.println("\tPenglaman\t\t: " + pengalaman);
        System.out.println("\t========================================================================");
    }
}
